# -*- coding: utf-8 -*-
"""
@author: Holden Scribner
"""
############
import pyodbc                                         
import pickle                                        
import pandas as pd                                  
from sklearn.linear_model import LogisticRegression   
from sklearn.model_selection import train_test_split 
from sklearn.metrics import accuracy_score 
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
###########

training_v1 = pd.read_csv("Insurance_claims_data_training_v1_hs166025.csv")
training_v2 = pd.read_csv("Insurance_claims_data_training_v2_hs166025.csv")
deployment_v1 = pd.read_csv("Insurance_claims_data_deployment_v1_hs166025.csv")

print(f"Rows: {len(training_v1)}")
print(f"Rows: {len(training_v2)}")
print(f"Rows: {len(deployment_v1)}")

##########

training_v1 = pd.read_csv("Insurance_claims_data_training_v1_hs166025.csv")
training_v1[["torque_nm", "torque_rpm"]] = training_v1["max_torque"].str.extract(r"([\d.]+)Nm@(\d+)rpm").astype(float)
training_v1[["power_bhp", "power_rpm"]] = training_v1["max_power"].str.extract(r"([\d.]+)bhp@(\d+)rpm").astype(float)
training_v1 = training_v1.drop(columns=["region_code", "model", "max_torque", "max_power"])

print(f"\nShape: {training_v1.shape}")
print(f"Rows: {len(training_v1)}")

calculation=(training_v1["claim_status"]==1).sum().sum()
percentage=(calculation/399)*100

print("Claims are filed % " + str(percentage) + " of the time.")

features = training_v1.drop(columns=["claim_status", "policy_id"])  
target = training_v1["claim_status"] 


features = pd.get_dummies(features, drop_first=True, dtype=int)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000, class_weight="balanced"))
model.fit(features, target) 
training_v1["claim_status"].iloc[0]  

#### Coefficient Print ####
logisticModel = model[-1]
coefficients = pd.Series(logisticModel.coef_[0], index=features.columns)
print(coefficients.sort_values(ascending=False))


pickle.dump(model, open("claims_model.pkl", "wb"))     
print("\nModel saved as claims_model.pkl")

connStr = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=cob.ohio.edu,6395;"                        
    "DATABASE=hs166025_ClaimsAnalysis;"     
    "Trusted_Connection=yes;")

connection = pyodbc.connect(connStr)           
cursor = connection.cursor() 

modelName = "claims_model"            
modelVersion = 1                                   
modelFile = open("claims_model.pkl", "rb").read()        
print(f"Model file size: {len(modelFile):,} bytes")

modelName = "claims_model"
version = 1

cursor.execute(
    "INSERT INTO Model (modelName, version, modelBlob) VALUES (?, ?, ?)",  
    modelName, modelVersion, pyodbc.Binary(modelFile))

deployment_v1 = pd.read_csv("Insurance_claims_data_deployment_v1_hs166025.csv")
deployment_v1 = deployment_v1.drop(columns=['claim_status'])

deployment_v1[["torque_nm", "torque_rpm"]] = deployment_v1["max_torque"].str.extract(r"([\d.]+)Nm@(\d+)rpm").astype(float)
deployment_v1[["power_bhp", "power_rpm"]] = deployment_v1["max_power"].str.extract(r"([\d.]+)bhp@(\d+)rpm").astype(float)
deploy_features = deployment_v1.drop(columns=["policy_id", "region_code", "model", "max_torque", "max_power"])

deploy_features = pd.get_dummies(deploy_features, drop_first=True, dtype=int)   

modelName = "claims_model"             
cursor.execute(
    "SELECT TOP 1 version, modelBlob FROM Model "  
    "WHERE modelName = ? "                         
    "ORDER BY version DESC, modelId DESC",          
    modelName)

row = cursor.fetchone()                            
modelVersion = row[0]                              
model = pickle.loads(row[1])  

deploy_features = deploy_features.reindex(columns=model.feature_names_in_, fill_value=0) 

scores = model.predict_proba(deploy_features)[:, 1]  
deployment_v1["claim_score"] = scores   
print("\nPredictions generated:")
print(deployment_v1[["policy_id", "claim_score"]].head(10))  

for each, eachRow in deployment_v1.iterrows():
    cursor.execute(
        "INSERT INTO Prediction (policy_id, claim_score, modelName, modelVersion) VALUES (?, ?, ?, ?)",
        int(eachRow["policy_id"].replace("POL", "")),   
        float(eachRow["claim_score"]),
        modelName, modelVersion)
connection.commit()  
                                           
print(f"\n{len(deployment_v1)} predictions written to database!")
rowsScored = len(deployment_v1)     
cursor.execute(
    "INSERT INTO PipelineRun (modelName, modelVersion, rowsScored) VALUES (?, ?, ?)", 
    modelName, modelVersion, rowsScored)
connection.commit() 

cursor.close()      
connection.close() 

MODEL_NAME = "claims_model"
FEATURE_COLS = ["vehicle_age", "customer_age", "region_density",
    "fuel_type", "max_torque", "max_power", "airbags",
    "is_parking_sensors", "is_parking_camera",
    "transmission_type", "steering_type", "ncap_rating",]

def LoadLatestModel(cursor):
    cursor.execute(
        "SELECT TOP 1 modelName, version, modelBlob FROM Model "
        "WHERE modelName = ? ORDER BY version DESC, modelId DESC",
        MODEL_NAME)
    row = cursor.fetchone()
    modelName = row[0]
    modelVersion = row[1]
    model = pickle.loads(row[2])
    return modelName, modelVersion, model

def LoadNewData():                        
    listOfRequiredCols = ["policy_id"] + FEATURE_COLS             
    for eachCol in listOfRequiredCols:                            
        if eachCol not in deployment_v1.columns:                       
            raise ValueError(f"Missing required column: {eachCol}") 
    return deployment_v1  

def ScoreCustomers(model, deploy_features):
    features = deploy_features.reindex(columns=model.feature_names_in_, fill_value=0)
    deployment_v1["claim_score"] = model.predict_proba(features)[:, 1]   
    return deployment_v1

def WritePredictions(cursor, deployment_v1):
    count = 0                                                          
    for each, eachRow in deployment_v1.iterrows():                     
        cursor.execute(
            "INSERT INTO Prediction (policy_id, claim_score) VALUES (?, ?)", 
            int(eachRow["policy_id"].replace("POL", "")), 
            float(eachRow["claim_score"]))
        count += 1
    return count 

def LogPipelineRun(cursor, modelName, modelVersion, rowsScored):
    cursor.execute(
        "INSERT INTO PipelineRun (modelName, modelVersion, rowsScored) VALUES (?, ?, ?)", 
        modelName, modelVersion, rowsScored)
    
def Main():
    connection = None                                              
    cursor = None                                                   
    try:                                                             
        connection = pyodbc.connect(connStr)                       
        cursor = connection.cursor()                               
        print("Starting pipeline...")
            
        modelName, version, model = LoadLatestModel(cursor)        
        print(f"Loaded model: {modelName} v{version}")              
            
        deploymentdf = LoadNewData()                                  
        print(f"Loaded {len(deploymentdf)} cases")                
          
        deploymentdf = ScoreCustomers(model, deploy_features)             
        print(f"Scored {len(deploymentdf)} cases")                
             
        numOfPredictions = WritePredictions(cursor, deployment_v1)     
        print(f"{numOfPredictions} predictions written to database")  
      
        LogPipelineRun(cursor, modelName, version, len(deployment_v1)) 
        print("Pipeline run logged")                               
        
        connection.commit()                                       
        print("Pipeline completed successfully!")
        
    except Exception as e:                                          
        if connection: connection.rollback()                      
        print(f"Pipeline failed: {e}")                          
        
    finally:                                                        
        if cursor: cursor.close()                                 
        if connection: connection.close()                           

if __name__ == "__main__":   
    Main() 

training_v2 = pd.read_csv("Insurance_claims_data_training_v2_hs166025.csv")
training_v2[["torque_nm", "torque_rpm"]] = training_v2["max_torque"].str.extract(r"([\d.]+)Nm@(\d+)rpm").astype(float)
training_v2[["power_bhp", "power_rpm"]] = training_v2["max_power"].str.extract(r"([\d.]+)bhp@(\d+)rpm").astype(float)

listOfFeatureCols = ["vehicle_age", "customer_age", "region_density",
    "fuel_type", "torque_nm", "torque_rpm", "power_bhp", "power_rpm",
    "airbags", "is_parking_sensors", "is_parking_camera",
    "transmission_type", "steering_type", "ncap_rating"]

features = pd.get_dummies(training_v2[listOfFeatureCols], drop_first=True, dtype=int)
target = training_v2["claim_status"]

featuresTrain, featuresTest, targetTrain, targetTest = train_test_split(
    features, target, test_size=0.3, random_state=42, stratify=target)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000, random_state=42, class_weight="balanced"))
model.fit(featuresTrain, targetTrain)

predictions = model.predict(featuresTest)  
accuracy = accuracy_score(targetTest, predictions) 

print(f"\nNew model accuracy: {accuracy:.2%}")

connStr = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=cob.ohio.edu,6395;"                          
    "DATABASE=hs166025_ClaimsAnalysis;"       
    "Trusted_Connection=yes;")

connection = pyodbc.connect(connStr)               
cursor = connection.cursor() 
modelName = "claims_model"

cursor.execute("SELECT MAX(version) FROM Model WHERE modelName = ?", modelName)
latestVersion = cursor.fetchone()[0] 

if latestVersion is None:                         
    newVersion = 1                                
else:
    newVersion = latestVersion + 1  

print(f"\nCurrent latest version: {latestVersion}")
print(f"New version number: {newVersion}")

modelBlob = pickle.dumps(model) 

cursor.execute("INSERT INTO Model (modelName, version, modelBlob) VALUES (?, ?, ?)", 
    modelName, newVersion, pyodbc.Binary(modelBlob))
cursor.execute("INSERT INTO ModelVersion (version, trainDateTime, accuracy) VALUES (?, GETDATE(), ?)", newVersion, accuracy)

connection.commit() 
cursor.close()                                                                            
connection.close()   

print(f"\nModel: {modelName}, version: {newVersion} stored in database!")
print(f"Accuracy ({accuracy:.2%}) logged in ModelVersion table.")
